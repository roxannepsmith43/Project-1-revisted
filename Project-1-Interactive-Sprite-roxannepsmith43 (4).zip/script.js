/**
* Project 1 - Interactive Image
* Name: Roxie Smith (6/25/22)
* Comments: In this project, a multi-layered sun appears on screen with clouds atop. If the user clicks and holds the mouse, the sun shifts to the right, and will eventually wrap back around. Simultaneously, the user can scale the size of the clouds by moving the mouse while pressing mouse.  
*/

function setup() {
  
  createCanvas(600, 300); // create a 600x300 pixel drawing canvas
}
  var x = 300
  var y = 300
  var r = 0
  var s = 1
function draw() {
  
  background(20, 26, 51); //dark blue background
  noStroke()
  translate(x,y);

  fill("green"); //green text
  text("Click to move sun and simultaneously move mouse for cloud scaling", 30, 20); 
  
  
  //Crown
  fill(250, 200, 90);   //yellow fill
      //crown count from left to right
  triangle(0, -285, -35, -245, 35, -245) //crown 3
  triangle(170, -240, 180, -180, 120, -210) //crown 4
  triangle(-160, -250, -80, -220, -175, -180) //crown 2
  triangle(295, -130, 230, -130, 260, -80) //crown 5
  triangle(-280, -130, -210, -140, -255, -80) //crown 1

  //Sun
  fill(250, 200, 90);   //yellow fill
  ellipse(0, 0, 550, 500); //yellow layer
  fill(240, 110, 10);   //orange fill
  ellipse(0, 0, 450, 400); //orange layer
  fill(240, 80, 150); //pink fill 
  ellipse(0, 0, 370, 320); //pink layer
  fill(240, 0, 0);  //red fill
  ellipse(0, 0, 250, 200); //red layer
  fill(250, 260, 230);  //tan fill
  ellipse(0, 0, 160, 120); //sun center


  if(mouseIsPressed){ //mouse press moves sun to right
  s = mouseY/height;
  scale(s); //clouds scale with mouse
  x++;
   if(x > 900){
     x = -300 //sun will wrap back around
   }}
  //Clouds 
  fill(220)
  ellipse (-20, -140, 80, 50); //cloud 2 top
  ellipse (0, -110, 80, 50); //cloud 2 bottom
  ellipse (-50, -130, 80, 40); //cloud 2 left
  ellipse (-150, -180, 60, 50); //cloud 1 top
  ellipse (-170, -160, 80, 50); //cloud 1 left
  ellipse (-150, -155, 50, 70); //cloud 1 bottom
  ellipse (150, -80, 70, 50); //cloud 3 top
  ellipse (200, -50, 80, 50); //cloud 3 right
  ellipse (140, -50, 70, 50); //cloud 3 left

} //end of draw() function